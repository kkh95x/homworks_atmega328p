#include <avr/io.h>
#include <util/delay.h>

// Define the rows and columns of the LED matrix
#define ROWS 8
#define COLS 8

// Define the patterns for numbers 0 to 9
const uint8_t numbers[10][8] = {
	{0b00000000, 0b01111100, 0b01000100, 0b01000100, 0b01000100, 0b01000100,  0b01000100,0b01111100}, // 0
	{0b00000000, 0b01000000, 0b01000000, 0b01000000, 0b01000000, 0b01000000, 0b01000000, 0b00000000}, // 1
	{0b00000000, 0b01111100, 0b01000000, 0b01000000, 0b01111100, 0b00000100, 0b00000100, 0b01111100}, // 2
	{0b00000000, 0b01111100, 0b01000000, 0b01000000, 0b01111100, 0b01000000, 0b01000000, 0b01111100}, // 3
	{0b00000000, 0b01000100, 0b01000100, 0b01000100, 0b01111100, 0b01000000, 0b01000000, 0b00000000}, // 1
	{0b00000000, 0b01111100, 0b00000100, 0b00000100, 0b01111100, 0b01000000, 0b01000000, 0b01111100}, // 5
	{0b00000000, 0b01111100, 0b00000100, 0b00000100, 0b01111100, 0b01000100, 0b01000100, 0b01111100}, // 6
	{0b00000000, 0b01111000, 0b01000000, 0b01000000, 0b01000000, 0b01000000, 0b01000000, 0b00000000}, // 7
	{0b00000000, 0b01111100, 0b01000100, 0b01000100, 0b01111100, 0b01000100, 0b01000100, 0b01111100}, // 8
	{0b00000000, 0b01111100, 0b01000100, 0b01000100, 0b01111100, 0b01000000, 0b01000000, 0b01111100}, // 9
};

void setup() {
	// Set PortB and PortD as outputs
	DDRB = 0xFF;
	DDRD = 0xFF;
}

void displayNumber(uint8_t number) {
	// Display the number on the LED matrix
	for (int i = 0; i < 8; i++) {
		// Set the columns (PortD) and rows (PortB) based on the pattern
		PORTD = ~(1 << i);
		PORTB = numbers[number][i];
		_delay_ms(1);
		 // Adjust the delay as needed
	}
}

int main() {
	setup();

	while (1) {
		// Display numbers 0 to 9
		for (uint8_t i = 0; i < 10; i++) {
			for (int k=0;k<100;k++)			
			displayNumber(i);
			
		}
	}

	return 0;
}
