/*
 * 7seg.h
 *
 * Created: 11/9/2023 2:34:39 PM
 *  Author: karim
 */ 


#ifndef FILE_H_
#define FILE_H_
#include <avr/io.h>


void init(int pin7seg1Enable, int pin7seg2Enable, int pinData, int pinSetCash, int pinSetOutput, int pinIncrement);
void showFrom0to99();
void showNumber(int num7Seg1, int num7Seg2);


#endif /* FILE_H_ */