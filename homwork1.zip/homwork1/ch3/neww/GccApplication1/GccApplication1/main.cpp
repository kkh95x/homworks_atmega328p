#include <avr/io.h>
#define F_CPU 8000000UL
#include <util/delay.h>

uint8_t x=0b01000101;
void mov1(void){
	for (uint8_t i=0;i<8;i++)
	{
		if(x & (1<<i)){
			PORTB|=(1<<PORTB0);
		}else{
			PORTB&=~(1<<PORTB0);
		}
	  _delay_ms(10);
	}
}
int main(void)
{
	DDRB=0xFF;
	while (1)
	{
		
		mov1();
		
		
		
	}
	
	
}

