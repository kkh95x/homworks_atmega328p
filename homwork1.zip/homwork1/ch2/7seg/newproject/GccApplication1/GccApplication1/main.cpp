#define F_CPU 16000000L
#include <avr/io.h>
#include <util/delay.h>
int main(void)
{
	int i;
	uint8_t segCode[]={0x3f, 0x06, 0x5B, 0x4f, 0x66, 0x6d, 0x7c, 0x07, 0x7f, 0x6f};
	DDRB=0xFF;
	PORTB=0x00;
	while(1){
		for (i = 0; i < 10; i++) {
			PORTB=segCode[i];
			
			_delay_ms(100);
		}
	}
	return 0;
}