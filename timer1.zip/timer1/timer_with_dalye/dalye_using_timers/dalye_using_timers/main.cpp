#include <avr/io.h>
#include <avr/interrupt.h>

// تعيين قيمة العداد الأولية للمؤقت
#define INITIAL_TIMER_VALUE 0

// تعيين قيمة الفاصل الزمني المطلوبة بالثواني
#define TIME_INTERVAL_IN_SECONDS 1

// تعيين تردد المعالج
#define CPU_FREQUENCY 16000000UL  // تعيين تردد المعالج إلى 16 ميجاهيرتز

// تعيين المقسم (Prescaler) بحسب الطلب
#define PRESCALER_VALUE 1024

// حساب القيمة المطلوبة للتحقق من توقيت الطفحان
#define TIMER_COUNT_VALUE ((CPU_FREQUENCY / PRESCALER_VALUE) * TIME_INTERVAL_IN_SECONDS)



void runTimer(uint16_t delay_ms, uint8_t timerControl) 
// دالة تقوم بإعداد المؤقت باستخدام مقاطعة الطفحان
void setupTimer() {
	// تعيين العداد إلى القيمة الأولية
	TCNT1 = INITIAL_TIMER_VALUE;

	// تعيين قيمة الطفحان المطلوبة
	OCR1A = TIMER_COUNT_VALUE;

	// تحديد وحدة الوقت (وضع CTC) وتعيين مقسم الساعة
	TCCR1B |= (1 << WGM12) | (1 << CS12) | (1 << CS10);

	// تحديد قيمة المقسم (Prescaler)
	TCCR1B |= (1 << CS12) | (1 << CS10);

	// تفعيل مقاطعة الطفحان
	TIMSK1 |= (1 << OCIE1A);

	// تفعيل الانقطاعات العامة
	sei();
}

// دالة المقاطعة التي ستتم تنفيذها عندما يحدث طفحان المؤقت
ISR(TIMER1_COMPA_vect) {


}

int main() {
	// إعداد المؤقت
	setupTimer();

=	while (1) {
		=
	}

	return 0;
}
//الطلب الثاني 


// دالة لتشغيل المؤقت 1T
void runTimer(uint16_t delay_ms, uint8_t timerControl) {
	// تعيين القيمة المطلوبة لتوقيت الطفحان
	uint16_t timerCount = (F_CPU / 1000) * delay_ms / 1024;
	
	// تعيين العداد إلى القيمة الأولية
	TCNT1 = 0;

	// تعيين قيمة الطفحان المطلوبة
	OCR1A = timerCount;

	// تحديد وحدة الوقت (وضع CTC) وتعيين مقسم الساعة إلى 1024
	TCCR1B |= (1 << WGM12) | (1 << CS12) | (1 << CS10);

	// تفعيل مقاطعة الطفحان
	TIMSK1 |= (1 << OCIE1A);

	// تحديد قيمة المقسم (Prescaler) وتشغيل/إيقاف المؤقت
	if (timerControl == 1) {
		TCCR1B |= (1 << CS12) | (1 << CS10);
		} else {
		TCCR1B &= ~((1 << CS12) | (1 << CS10));
	}

	// الانتظار حتى ينتهي المؤقت
	while (bit_is_set(TIFR1, OCF1A) == 0);

	// إيقاف المؤقت
	TCCR1B &= ~((1 << CS12) | (1 << CS10));

	// مسح علامة الطفحان
	TIFR1 |= (1 << OCF1A);
}

// دالة المقاطعة التي ستتم تنفيذها عندما يحدث طفحان المؤقت
ISR(TIMER1_COMPA_vect) {
	// يمكنك وضع الشيفرة التي تريدها هنا
}

int main() {
	// تشغيل المؤقت لمدة 1000 مللي ثانية وثم إيقافه
	runTimer(1000, 1);
	
	// الشيفرة الرئيسية هنا
	while (1) {
		// يمكنك وضع الشيفرة التي تريدها هنا
	}

	return 0;
}
