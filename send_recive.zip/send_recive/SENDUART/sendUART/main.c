
#include <avr/io.h>
#include <util/delay.h>
#define F_CPU 16000000UL
#define BR 9600 // define baud rate
#define BAUDRATE ((F_CPU)/(BR*16UL)-1)// set baud rate value for UBRR
// IO Pins Defines
#define UP   PORTB0
#define Down PORTB1
#define Send PORTB2
#define CHECKBIT(x, BitNum) (!(x & (1<<BitNum))) // Check bit BitNum in byte x
// Functions Declarations
void UART_TX_Init(void) ;
void UART_Write(uint8_t);

int main(void)
{
	DDRB=0X00; 
	PORTB=0XFF;
	UART_TX_Init();      // Initialize The UART in Master Mode @ 9600bps
	uint8_t Data = 0;    // The Data Byte
	
   
    while (1) 
    {
		if (CHECKBIT(PINB,UP)) // Increment The Data Value
		{
			Data++;
			_delay_ms(250);
		}
		if (CHECKBIT(PINB,Down)) // Decrement The Data Value
		{
			Data--;
			_delay_ms(250);
		}
		if (CHECKBIT(PINB,Send)) // Send The Current Data Value Via UART
		{
			UART_Write(Data);
			_delay_ms(250);
		}
		PORTC = Data;
    }
	return;
}



void UART_TX_Init(void)
{
	UBRR0H = (BAUDRATE>>8); // shift the register right by 8 bits
	UBRR0L = BAUDRATE;     // set baud rate
	UCSR0B|= (1<<TXEN0);   // enable transmitter
	UCSR0C|= (1<<UCSZ00)|(1<<UCSZ01); // 8-bits data format
}
void UART_Write(unsigned char Data)
{
	while (!( UCSR0A & (1<<UDRE0))); // Wait for empty transmit buffer
	UDR0 = Data; // Put data into the buffer, sends the data
}
