#include <avr/io.h>
#define ckeakbit(x,bitn)(x &(1<<bitn))
#define setbit(x,bitn)(x=x|(1<<bitn))
#define clear(x,bitn)(x=x&~(1<<bitn))
#define F_CPU 8000000UL
#include <util/delay.h>
int main(void)
{
	DDRB=0xFF;
	uint8_t x=0b11010011;
    while (1) 
    {
			for (uint8_t i=0;i<8;i++)
			{
				if (ckeakbit(x,i))
				{
					setbit(PORTB,i);
					_delay_ms(100);
				}
				else{
					clear(PORTB,i);
					
					_delay_ms(100);
				}
			}
    }
	return 0;
}

