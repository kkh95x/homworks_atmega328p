#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <LiquidCrystal_I2C.h>

// تعريف متحكم الشاشة LCD
LiquidCrystal_I2C lcd(0x27, 16, 2);

// متغير لحفظ عدد النبضات خلال فاصل الزمن
volatile uint16_t pulseCount = 0;

// دالة لتحديد المؤقت لتوليد فاصل زمني
void setupTimer() {
	// تحديد وحدة الوقت (وضع CTC) وتعيين مقسم الساعة إلى 1024
	TCCR1B |= (1 << WGM12) | (1 << CS12) | (1 << CS10);

	// تحديد قيمة الطفحان المطلوبة لفاصل زمني 1 ثانية
	OCR1A = 15624;

	// تفعيل مقاطعة الطفحان
	TIMSK1 |= (1 << OCIE1A);

	// تفعيل الانقطاعات العامة
	sei();
}

// دالة المقاطعة التي ستتم تنفيذها عندما يحدث طفحان المؤقت
ISR(TIMER1_COMPA_vect) {
	// زيادة عدد النبضات خلال فاصل الزمن
	pulseCount++;
}

// دالة لقياس تردد الإشارة المربعة
float measureFrequency(uint16_t duration) {
	return (float)pulseCount / duration;
}

int main() {
	// إعداد المؤقت
	setupTimer();

	// إعداد شاشة LCD
	lcd.begin(16, 2);

	// الشيفرة الرئيسية هنا
	while (1) {
		// انتظر لمدة 1 ثانية لقياس تردد الإشارة
		_delay_ms(1000);

		// قياس تردد الإشارة خلال الثانية
		float frequency = measureFrequency(1000);

		// عرض قيمة التردد على شاشة LCD
		lcd.clear();
		lcd.setCursor(0, 0);
		lcd.print("Frequency: ");
		lcd.print(frequency);
		lcd.print(" Hz");
		
		// إعادة تعيين عدد النبضات للفترة التالية
		pulseCount = 0;
	}

	return 0;
}
