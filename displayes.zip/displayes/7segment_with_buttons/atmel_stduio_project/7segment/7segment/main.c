/*
 * 7segment.cpp
 *
 * Created: 11/9/2023 5:55:42 PM
 * Author : karim
 */ 

#include <avr/io.h>
#include "7seg.h"


int main(void)
{
    /* Replace with your application code */
    DDRD = 0xf4;
	PORTD|=0b00000011;
 	init(3,4,6,7,5,2);

 	while (1)
 	{
 		showFrom0to99();

 	}
}

