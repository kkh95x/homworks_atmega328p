/*
 * lcd.h
 *
 * Created: 11/9/2023 6:10:20 PM
 *  Author: karim
 */ 


#ifndef LCD_H_
#define LCD_H_


void LCD_String_xy (char row, char pos, char *str);
void LCD_String (char *str);
void LCD_Char( unsigned char data );
void LCD_Init (void);
void LCD_Command( unsigned char cmnd );
void LCD_Clear();
void LCD_Num(uint8_t num,uint8_t digitNum);

#endif /* LCD_H_ */