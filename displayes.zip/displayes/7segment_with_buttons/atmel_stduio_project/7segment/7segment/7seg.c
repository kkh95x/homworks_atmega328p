/*
 * _7seg.c
 *
 * Created: 11/9/2023 5:56:09 PM
 *  Author: karim
 */ 




#include <avr/io.h>

#include "7seg.h"



int index = 0;
int index2 = 0;
int isPressed = 1;
int isPressed2 = 2;
int _pin7seg1Enable;
int _pin7seg2Enable;
int _pinData;
int _pinSetCash;
int _pinSetOutput;
int _pinIncrement;

void init(int pin7seg1Enable,
int pin7seg2Enable,
int pinData,
int pinSetCash,
int pinSetOutput,
int pinIncrement){
	_pin7seg1Enable=pin7seg1Enable;
	_pin7seg2Enable=pin7seg2Enable;
	_pinData=pinData;
	_pinSetCash=pinSetCash;
	_pinSetOutput=pinSetOutput;
	_pinIncrement=pinIncrement;
}
uint8_t numbers[10] = {
	0b1111110, // 0
	0b0110000, // 1
	0b1101101, // 2
	0b1111001, // 3
	0b0110011, // 4
	0b1011011, // 5
	0b1011111, // 6
	0b1110000, // 7
	0b1111111, // 8
	0b1111011  // 9
};
void refresh(){
	for (int i = 0; i < 8; i++) {
		PORTD =   (1 << _pinSetCash)|(1<<_pinData);
		PORTD = PORTD & (~(1 << _pinSetCash));
	}
	PORTD = (1 << _pinSetOutput) ;

}
void uploadNumber(uint8_t number, int lcnum) {
	refresh();

	for (int i = 0; i < 7; i++) {
		PORTD =  ((number & 0x01) << _pinData) | (1 << _pinSetCash);
		PORTD = PORTD & ~(1 << _pinSetCash);
		number = number >> 1;
	}
	PORTD =PORTD & ( ~(1 << _pinSetOutput) );
	PORTD = (1 << 5) | (1 << lcnum);
}
void increment(){
	index++;
	if (index == 10) {
		index = 0;
		index2++;
		if (index2 == 10) {
			index2 = 0;
		}
	}
}
void dicrement(){
	index--;
	if (index< 0) {
		index = 9;
		index2--;
		if (index2 <0) {
			index2 =9;
		}
	}
}
void showFrom0to99(){
	uploadNumber(~numbers[index], _pin7seg1Enable);
	uploadNumber(~numbers[index2], _pin7seg2Enable);
	
	if(PIND & (1<<PIND1)){
	if(isPressed){
		isPressed=0;
		increment();
	}
	}
	else
	{
	isPressed=1;
}
if(PIND & (1<<PIND0)){
	if(isPressed2){
		isPressed2=0;
		dicrement();
	}
	}else{
	isPressed2=1;
}
}

void showNumber(int num7Seg1,int num7Seg2){
	uploadNumber(~numbers[num7Seg1], _pin7seg1Enable);
	uploadNumber(~numbers[num7Seg2], _pin7seg2Enable);

}
//int main(void)
//{
/* Replace with your application code */
//	DDRD = 0xf4;
//	init(3,4,6,7,5,2);

//	while (1)
//	{
//		showFrom0to99();

//	}
//}



