#include <avr/io.h>
#define F_CPU 16000000U
#include <util/delay.h>
#define Togle(x,bit)(x=x^(1<<bit))
 int main(void){
	 DDRB=0xFF;
	 PORTB=0x00;
	 while (1)
	 {
		 PORTB=0x00;
		 for (uint8_t i=0;i<8;i+=2)
		 {
			 Togle(PORTB,i);
		 }
		 _delay_ms(100);
		 PORTB=0x00;
		  for (uint8_t i=1;i<8;i+=2)
		  {
			  Togle(PORTB,i);
		  }
		  _delay_ms(100);
	 }
 }