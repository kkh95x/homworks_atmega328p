#include <avr/io.h>
#define F_CPU 1000000UL
#include <util/delay.h>

// Define the rows and columns of the LED matrix
#define ROWS 8
#define COLS 8

// Define the patterns for numbers 0 to 9
const uint8_t numbers[11][8] = {
	{0b00000000, 0b01111100, 0b00010000, 0b00010000, 0b00010000, 0b00010000, 0b01111100, 0b00000000}, // I
	{0b00000000, 0b01000100, 0b01001100, 0b01010100, 0b01100100, 0b01000100, 0b01000100, 0b00000000}, // N
	{0b00000000, 0b01111100, 0b00000100, 0b00000100, 0b01111100, 0b00000100, 0b00000100, 0b00000000}, // F
	{0b00000000, 0b00111100, 0b01000010, 0b01000010, 0b01000010, 0b01000010, 0b00111100, 0b00000000}, // O
	{0b00000000, 0b00111100, 0b01000100, 0b01000100, 0b00111100, 0b01000100, 0b01000100, 0b00000000}, // R
	{0b00000000, 0b01000100, 0b01101100, 0b01010100, 0b01000100, 0b01000100, 0b01000100, 0b00000000}, // M
	{0b00000000, 0b01111100, 0b01000100, 0b01000100, 0b01111100, 0b01000100, 0b01000100, 0b00000000}, // A
	{0b00000000, 0b01111110, 0b00010000, 0b00010000, 0b00010000, 0b00010000, 0b00010000, 0b00000000}, // T
	{0b00000000, 0b01111100, 0b00010000, 0b00010000, 0b00010000, 0b00010000, 0b01111100, 0b00000000}, // I
	{0b00000000, 0b01111000, 0b00000100, 0b00000100, 0b00000100, 0b00000100, 0b01111000, 0b00000000}, // C
	{0b00000000, 0b01111000, 0b00000100, 0b00000100, 0b00111000, 0b01000000, 0b01000000, 0b00111100}, // S
};

void setup() {
	// Set PortB and PortD as outputs
	DDRB = 0xFF;
	DDRD = 0xFF;
}

void displayNumber(uint8_t* number) {
	// Display the number on the LED matrix
	
	for (int i = 0; i < 8; i++) {
		// Set the columns (PortD) and rows (PortB) based on the pattern
		PORTD = ~(1 << i);
		PORTB = number[i];
		
		
		// Adjust the delay as needed
	}
}
uint8_t temp[12];
uint8_t* showNumberWithD(uint8_t number,int dura){
	
    
	
	for (int i=0;i<8;i++)
	{
		     if(dura>=4){
		temp[i]=numbers[number][i]>>(dura-4);
		
			 }else{
				 temp[i]=numbers[number][i]<<(4-dura);
			 }
			
		
		
	}	
	return temp;
	
	
	
	
}

int main() {
	setup();

	while (1) {
		// Display chars INFORMATICS
		for (uint8_t i = 0; i < 11; i++) {
			
			for (int j=0;j<8;j++)
			{   for (int k=0;k<200;k++)			{
				
				
				displayNumber(showNumberWithD(i,j));
				//_delay_ms(1);
			}
			}
			
			
		}
	}

	return 0;
}
