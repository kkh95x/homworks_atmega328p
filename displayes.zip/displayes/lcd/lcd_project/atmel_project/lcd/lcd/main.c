/*
 * lcd.c
 *
 * Created: 11/9/2023 6:09:29 PM
 * Author : karim
 */ 

#include <avr/io.h>
#define F_CPU 16000000

#include "lcdLib.h"
#include <util/delay.h>
#include <string.h>
int main(void)
{
    /* Replace with your application code */
LCD_Init();/* Initialization of LCD*/

int n=0;

while(1){
	
	     char x[4];
		 itoa(n,x,10);
		LCD_String_xy(1,1,x);
			
		
		_delay_ms(1000);


	


n++;
if(n==100)n=0;

	
	};
}

